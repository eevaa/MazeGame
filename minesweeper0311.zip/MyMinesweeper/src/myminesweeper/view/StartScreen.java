/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myminesweeper.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import myminesweeper.controller.LevelChooser;

/**
 *
 * @author EEvAA
 */
public class StartScreen extends JFrame{
    private JFrame frame;
    private JLabel level;
    private JLabel gameTitle;
    private JRadioButton easy;
    private JRadioButton normal;
    private JRadioButton hard;
    private JButton start;
    private JPanel main;
    private JPanel gameName;
    private JPanel footer;
    private JPanel levels;
    private static Image mouse;
    private static Image rabbit;
    private static Image monkey;
    
    
    public StartScreen() {
        setImage();
        
        main = new JPanel();
        gameName = new JPanel();
        levels = new JPanel();
        footer = new JPanel();
        
        gameTitle = new JLabel("Don't get trapped!");
        gameTitle.setFont(new Font("Courier", Font.PLAIN, 24));
        gameName.add(gameTitle);
        
        level = new JLabel("Choose level");
        easy = new JRadioButton();
        normal = new JRadioButton();
        hard = new JRadioButton();
        

        
        easy.setIcon(new ImageIcon(mouse));
        easy.setBorderPainted(true);
        normal.setIcon(new ImageIcon(rabbit));
        normal.setBorderPainted(true);
        hard.setIcon(new ImageIcon(monkey));
        hard.setBorderPainted(true);
        
        ButtonGroup chooseLevel = new ButtonGroup();
        chooseLevel.add(easy);
        chooseLevel.add(normal);
        chooseLevel.add(hard);
        
        start = new JButton("Start");
        start.addActionListener(new LevelChooser());
       
        levels.setBackground(Color.WHITE);
        levels.add(easy);
        levels.add(normal);
        levels.add(hard);
        levels.add(start);
        
        main.add(gameName);
        main.add(levels);
        
        this.getContentPane().add(main);
        this.setSize(900,900);
        this.setBackground(Color.WHITE);
        this.setVisible(true);
        
    }
    
    public static void main(String[] args) {
        StartScreen start = new StartScreen();
        
    }
    
    public void setImage(){
        try {
                mouse = ImageIO.read(this.getClass().getResource("../images/mouse.jpg"));
                mouse = mouse.getScaledInstance(200,200,1);
                rabbit = ImageIO.read(this.getClass().getResource("../images/rabbit.jpg"));
                rabbit = rabbit.getScaledInstance(200,200,1);
                monkey = ImageIO.read(this.getClass().getResource("../images/monkey.jpg"));
                monkey = monkey.getScaledInstance(200,200,1);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
    }
}
