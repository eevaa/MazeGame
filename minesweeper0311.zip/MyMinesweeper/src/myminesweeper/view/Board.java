
package myminesweeper.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import myminesweeper.controller.ButtonController;
//import myminesweeper.controller.LifeController;

/**
 *
 * @author Iva Karabatic
 */
public class Board extends JFrame{

    private JPanel boardPanel;
    private JPanel textPanel;
    public static JLabel time;
    public static JLabel life;
    private JLabel mines;
    
    private JButton[][] buttons;
    private String[][] buttonValue;
    public boolean[][] buttonClicked;
    Container boardContainer = new Container();
    

    
    public Board(){
        time = new JLabel();
        life = new JLabel(ButtonController.returnLife() + "");

        textPanel = new JPanel();
        textPanel.setLayout(new FlowLayout());
        textPanel.add(time);
        textPanel.add(life);
        boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(20,20));
        buttons = new JButton[20][20];
        buttonClicked = new boolean[20][20];
        

        
        for (int i=0; i<20; i++){
            for (int j=0; j<20; j++){
                buttons[i][j] = new JButton();
                System.out.println("new btn created");
                //buttons[i][j].setText(fieldSize[i][j]+"");
                buttons[i][j].addActionListener(new ButtonController(i,j, buttons));                
                boardPanel.add(buttons[i][j]);
                buttons[i][j].setPreferredSize(new Dimension(30,30));
                buttons[i][j].setMargin(new Insets(0,0,0,0));
            }
        }
        
        this.getContentPane().add(textPanel, BorderLayout.NORTH);
        this.getContentPane().add(boardPanel, BorderLayout.CENTER);
        this.setSize(600,600);
        this.pack();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    

    
}
    
    

