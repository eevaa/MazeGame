/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myminesweeper.controller;

import java.util.TimerTask;
import java.util.Timer;
import myminesweeper.model.GameGrid;
import myminesweeper.view.Board;

/**
 *
 * @author EEvAA
 */
public class Controller{
    public static int fieldVal[][];
    public static boolean lifeVal[][];
    int time = 0;
    
    public Controller(){
       
        int size = 20;
        int mineNum = 50;
        
                
        GameGrid grid = new GameGrid(20,50);
        grid.setFieldValue(size);
        System.out.println("setFieldValue");
        grid.setMines(size, mineNum);
        System.out.println("setMInes");
        grid.setNewFieldValue(size);
        System.out.println("setNewFieldValue");
        fieldVal = grid.returnFieldValue();
        //grid.setLifeUpper();
        
        grid.setLifeUpper();
        lifeVal = grid.returnLifeUpper();
        
        Board theBoard = new Board();
        theBoard.setVisible(true);
        
        Timer timer = new Timer();
        timer.schedule(new TimerTask(){
        @Override
        public void run(){
        time ++;
        Board.time.setText(String.valueOf(time));
        //Board.time.repaint();
        }
        }, 1000, 1000);
        
    }

    public static int[][] returnFieldValue(){
    return fieldVal;
    }
    public static boolean[][] returnLifeValue(){
        return lifeVal;
    }
    
}
    
    
    

