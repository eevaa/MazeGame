/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myminesweeper.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import myminesweeper.model.GameGrid;
import myminesweeper.view.Board;

/**
 *
 * @author EEvAA
 */
public class ButtonController implements ActionListener{
    
    int x, y;
    private final JButton[][] clickedButtons;
    protected static int[][] fieldValueCopy;
    protected static boolean[][] buttonsLife;
    boolean zeroChecker;
    int life;
    

    public ButtonController(int i, int j, JButton[][] buttons){
        clickedButtons = buttons;
        x = i; y = j;
        //getFieldValue(x,y);
        fieldValueCopy = Controller.fieldVal;
        buttonsLife = Controller.lifeVal;
        //System.out.println(fieldValueCopy[3][3]);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(buttonsLife[x][y]);
        if(fieldValueCopy[x][y] != 0 && fieldValueCopy[x][y] != 9){
            clickedButtons[x][y].setEnabled(false);
            clickedButtons[x][y].setText(fieldValueCopy[x][y]+"");
        }
        
        if(fieldValueCopy[x][y] == 0){
            if(buttonsLife[x][y] == true){
                GameGrid.increaseLife();
                System.out.println("life: " + GameGrid.getLife());
            }
            clickedButtons[x][y].setEnabled(false);          
            findZeros(x,y);
        }
        if(fieldValueCopy[x][y] == 9){
            clickedButtons[x][y].setEnabled(false);
            //clickedButtons[x][y].setFont(new Font("Arial", Font.PLAIN, 10));
            clickedButtons[x][y].setText("B");
            GameGrid.decreaseLife();
            Board.life.setText(""+GameGrid.getLife());
            if(GameGrid.getLife()<=0){
                System.out.println("GAME OVER!");
            }
        }
    }
    
    private boolean isInsideGrid(int i, int j) {
        return (i >= 0 && i < fieldValueCopy.length) && 
               (j >= 0 && j < fieldValueCopy[0].length);
    }
    
    private void findZeros(int findX, int findY){
        
        //up left cell
        if (isInsideGrid(findX-1, findY-1)){
            if(fieldValueCopy[findX-1][findY-1] == 0 && clickedButtons[findX-1][findY-1].isEnabled()){
                //System.out.println(isInsideGrid(findX-1, findY-1));
                clickedButtons[findX-1][findY-1].setEnabled(false);
                findZeros(findX-1,findY-1);

            }
            else if(clickedButtons[findX-1][findY-1].isEnabled()){
                clickedButtons[findX-1][findY-1].setEnabled(false);
                clickedButtons[findX-1][findY-1].setText(fieldValueCopy[findX-1][findY-1]+"");
            }
        }
        
        //left cell
        if(isInsideGrid(findX-1, findY)){
            if(fieldValueCopy[findX-1][findY] == 0 && clickedButtons[findX-1][findY].isEnabled()){
                clickedButtons[findX-1][findY].setEnabled(false);
                findZeros(findX-1,findY);
            }
            else if(clickedButtons[findX-1][findY].isEnabled()){
                clickedButtons[findX-1][findY].setEnabled(false);
                clickedButtons[findX-1][findY].setText(fieldValueCopy[findX-1][findY]+"");
            }
        }
        //bottom left cell
        if (isInsideGrid(findX-1, findY+1)){
            if(fieldValueCopy[findX-1][findY+1] == 0 && clickedButtons[findX-1][findY+1].isEnabled()){
                clickedButtons[findX-1][findY+1].setEnabled(false);
                findZeros(findX-1,findY+1);
            }
            else if(clickedButtons[findX-1][findY+1].isEnabled()){
                clickedButtons[findX-1][findY+1].setEnabled(false);
                clickedButtons[findX-1][findY+1].setText(fieldValueCopy[findX-1][findY+1]+"");
            }
        }
        //top cell
        if (isInsideGrid(findX, findY-1)){
            if(fieldValueCopy[findX][findY-1] == 0 && clickedButtons[findX][findY-1].isEnabled()){
                clickedButtons[findX][findY-1].setEnabled(false);
                findZeros(findX,findY-1);
            }
            else if(clickedButtons[findX][findY-1].isEnabled()){
                    clickedButtons[findX][findY-1].setEnabled(false);
                    clickedButtons[findX][findY-1].setText(fieldValueCopy[findX][findY-1]+"");
            }
        }
        //bottom cell
        if (isInsideGrid(findX, findY+1)){
            if(fieldValueCopy[findX][findY+1] == 0 && clickedButtons[findX][findY+1].isEnabled()){
                clickedButtons[findX][findY+1].setEnabled(false);
                findZeros(findX,findY+1);
            }
            else if(clickedButtons[findX][findY+1].isEnabled()){
                    clickedButtons[findX][findY+1].setEnabled(false);
                    clickedButtons[findX][findY+1].setText(fieldValueCopy[findX][findY+1]+"");
            }
        }
        //right top cell
        if (isInsideGrid(findX+1, findY-1)){
            if(fieldValueCopy[findX+1][findY-1] == 0 && clickedButtons[findX+1][findY-1].isEnabled()){
                clickedButtons[findX+1][findY-1].setEnabled(false);
                findZeros(findX+1,findY-1);
            }
            else if(clickedButtons[findX+1][findY-1].isEnabled()){
                    clickedButtons[findX+1][findY-1].setEnabled(false);
                    clickedButtons[findX+1][findY-1].setText(fieldValueCopy[findX+1][findY-1]+"");
            }
        }
        //right cell
        if (isInsideGrid(findX+1, findY)){
            if(fieldValueCopy[findX+1][findY] == 0 && clickedButtons[findX+1][findY].isEnabled()){
                clickedButtons[findX+1][findY].setEnabled(false);
                findZeros(findX+1,findY);
            }
            else if(clickedButtons[findX+1][findY].isEnabled()){
                    clickedButtons[findX+1][findY].setEnabled(false);
                    clickedButtons[findX+1][findY].setText(fieldValueCopy[findX+1][findY]+"");
            }
        }
        //right bottom cell
        if (isInsideGrid(findX+1, findY+1)){
            if(fieldValueCopy[findX+1][findY+1] == 0 && clickedButtons[findX+1][findY+1].isEnabled()){
                clickedButtons[findX+1][findY+1].setEnabled(false);
                findZeros(findX+1,findY+1);
            }
            else if(clickedButtons[findX+1][findY+1].isEnabled()){
                    clickedButtons[findX+1][findY+1].setEnabled(false);
                    clickedButtons[findX+1][findY+1].setText(fieldValueCopy[findX+1][findY+1]+"");
            }
        }
     }
    
    public static int returnLife(){
        return GameGrid.getLife();
    }
    
}
