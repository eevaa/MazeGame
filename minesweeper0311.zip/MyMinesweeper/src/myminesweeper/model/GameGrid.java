
package myminesweeper.model;


import java.util.Random;

/**
 *
 * @author EEvAA
 */
public class GameGrid {
    
    private int fieldValue[][];
    private static int life = 3;
    private boolean lifeUpper[][];
    
    private final int size, mineNum;
    /**
     *
     * @param fieldSize
     * @param mineNumber
     */
    public GameGrid(int fieldSize, int mineNumber){
        System.out.println("new obj created");
        size = fieldSize;
        mineNum = mineNumber;
    }
    
    /**
     *
     * @param size
     */
    public void setFieldValue(int size){
        for (int i=0; i<size; i++){
            fieldValue = new int[size][size]; 
            for(int j=0; j<size; j++){
                fieldValue[i][j] = 0;
            }
        }
    }
    

    public void setMines(int size, int mineNum){
        Random random = new Random();
        for (int i=0; i<mineNum; i++){
            int x = random.nextInt(size);
            int y = random.nextInt(size);
            if(fieldValue[x][y] != 9){
                fieldValue[x][y] = 9;
            }
            else i--;
        }
    }     
    
    public void setNewFieldValue(int size) {
      
        for(int i = 0; i < size; i++) {
            for(int j = 0; j < size; j++) {
                if(fieldValue[i][j] == 9) {
                    // previous row
                    incrementFieldValue(i-1, j-1);
                    incrementFieldValue(i-1, j);
                    incrementFieldValue(i-1, j+1);

                    // left and right cells
                    incrementFieldValue(i, j-1);
                    incrementFieldValue(i, j+1);

                    // next row
                    incrementFieldValue(i+1, j-1);
                    incrementFieldValue(i+1, j);
                    incrementFieldValue(i+1, j+1);
                }
            }	
        }
  
    }
    
    private void incrementFieldValue(int i, int j) {
        if(isInsideGrid(i, j) && fieldValue[i][j] != 9) {
            fieldValue[i][j]++;
        }
    }
     
    private boolean isInsideGrid(int i, int j) {
        return (i >= 0 && i < fieldValue.length) && 
               (j >= 0 && j < fieldValue[0].length);
    }
    

    public int[][] returnFieldValue(){
        return fieldValue;
    }
    //life
    
    public void fillLifeUpper(){
        lifeUpper = new boolean [fieldValue.length][fieldValue.length];
        for(int i = 0; i < fieldValue.length; i++){
            for(int j = 0; j < fieldValue[0].length; j++){
                lifeUpper[i][j] = false;
            }
        }
    }
    
    public void setLifeUpper(){
        fillLifeUpper();
        Random random = new Random();
        for(int k = 0; k < 5; k++){
            int x = random.nextInt(fieldValue.length);
            int y = random.nextInt(fieldValue.length);
            if(fieldValue[x][y] == 0 && lifeUpper[x][y] == false){
                lifeUpper[x][y] = true;
                System.out.println(lifeUpper[x][y] + " " +x+" "+y);
            }
            else k--;
        }
    }
    
    public boolean[][] returnLifeUpper(){
        return lifeUpper;
    }
    
    public static int getLife(){
        return life;    
    }
    public static void increaseLife(){
        life++;
    }
    public static void decreaseLife(){
        life--;
    }

}

