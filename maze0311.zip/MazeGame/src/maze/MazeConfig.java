package maze;

import java.util.ArrayList;

import javax.swing.JPanel;

public class MazeConfig {
	ArrayList<JPanel> walls=new ArrayList<JPanel>();
	
	public MazeConfig() {
		// TODO Auto-generated constructor stub
	}
	
}
